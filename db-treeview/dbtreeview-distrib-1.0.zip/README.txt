PHP DBTreeView - README file
version 1.0 (17 aug 2007)


Documentation
-------------

See ./doc directory.



License
-------

See LICENSE.txt for the licenses of the scripts included in this library.
The pictures in the 'media' directory are NOT part of this library and are used for demonstration only. Some pictures (directory icons, '+' icon, '-' icon) are copyrighted (Microsoft Windows). Don't use these pictures without having the appropriate licenses.



KNOWN BUGS
----------


TO DO
-----
Limitations :
- Attributes name and values : cannot contains tabulations and line breaks.

Enhancements:
- To create global parameters (in addition to node parameters)
- Refresh function : refresh partial treeview on demand


